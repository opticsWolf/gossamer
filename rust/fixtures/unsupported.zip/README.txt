not a wheel or sdist
